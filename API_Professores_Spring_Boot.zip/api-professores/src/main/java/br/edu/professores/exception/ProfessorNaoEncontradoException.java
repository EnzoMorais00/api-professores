package br.edu.professores.exception;

public class ProfessorNaoEncontradoException extends RuntimeException {
    public ProfessorNaoEncontradoException(Long id) {
        super("Professor com id " + id + " não encontrado");
    }
}
