package br.edu.professores.service;

import br.edu.professores.dto.ProfessorRequest;
import br.edu.professores.exception.ProfessorNaoEncontradoException;
import br.edu.professores.model.Professor;
import br.edu.professores.repository.ProfessorRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.text.Normalizer;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class ProfessorService {
    private final ProfessorRepository repository;

    public ProfessorService(ProfessorRepository repository) {
        this.repository = repository;
    }

    public List<Professor> listar() {
        return repository.findAll(Sort.by("id"));
    }

    public Professor buscarPorId(Long id) {
        return repository.findById(id).orElseThrow(() -> new ProfessorNaoEncontradoException(id));
    }

    public List<Professor> filtrarPorNome(String nome) {
        String normalizado = Normalizer.normalize(nome.strip(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        return repository.findByNomeBuscaContainingIgnoreCaseOrderByIdAsc(normalizado);
    }

    public List<Professor> filtrarPorArea(String area) {
        return repository.findByAreaIgnoreCaseOrderByIdAsc(area.strip());
    }

    @Transactional
    public Professor cadastrar(ProfessorRequest dados) {
        return repository.save(new Professor(dados.nome().strip(), dados.email().strip(),
                dados.area().strip(), dados.telefone().strip()));
    }

    @Transactional
    public Professor atualizar(Long id, ProfessorRequest dados) {
        Professor professor = buscarPorId(id);
        professor.setNome(dados.nome().strip());
        professor.setEmail(dados.email().strip());
        professor.setArea(dados.area().strip());
        professor.setTelefone(dados.telefone().strip());
        return repository.save(professor);
    }

    @Transactional
    public void excluir(Long id) {
        repository.delete(buscarPorId(id));
    }
}
