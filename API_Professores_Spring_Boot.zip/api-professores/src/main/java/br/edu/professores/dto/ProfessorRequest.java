package br.edu.professores.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ProfessorRequest(
        @NotBlank(message = "O nome é obrigatório")
        @Size(max = 100, message = "O nome deve ter até 100 caracteres") String nome,
        @NotBlank(message = "O e-mail é obrigatório")
        @Email(message = "O e-mail deve ser válido")
        @Size(max = 150, message = "O e-mail deve ter até 150 caracteres") String email,
        @NotBlank(message = "A área é obrigatória")
        @Size(max = 100, message = "A área deve ter até 100 caracteres") String area,
        @NotBlank(message = "O telefone é obrigatório")
        @Size(max = 20, message = "O telefone deve ter até 20 caracteres") String telefone
) { }
