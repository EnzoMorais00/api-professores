package br.edu.professores.repository;

import br.edu.professores.model.Professor;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProfessorRepository extends JpaRepository<Professor, Long> {
    // Consultas derivadas: o Spring interpreta os nomes dos métodos.
    List<Professor> findByNomeBuscaContainingIgnoreCaseOrderByIdAsc(String nome);
    List<Professor> findByAreaIgnoreCaseOrderByIdAsc(String area);
}
