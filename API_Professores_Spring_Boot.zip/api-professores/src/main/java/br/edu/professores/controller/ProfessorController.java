package br.edu.professores.controller;

import br.edu.professores.dto.ProfessorRequest;
import br.edu.professores.model.Professor;
import br.edu.professores.service.ProfessorService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/professores")
public class ProfessorController {
    private final ProfessorService service;

    public ProfessorController(ProfessorService service) { this.service = service; }

    @GetMapping
    public List<Professor> listar() { return service.listar(); }

    // Endpoint adicional para consultar e verificar o recurso criado/excluído.
    @GetMapping("/{id}")
    public Professor buscarPorId(@PathVariable Long id) { return service.buscarPorId(id); }

    @GetMapping("/nome/{nome}")
    public List<Professor> filtrarPorNome(@PathVariable String nome) {
        return service.filtrarPorNome(nome);
    }

    @GetMapping("/area/{area}")
    public List<Professor> filtrarPorArea(@PathVariable String area) {
        return service.filtrarPorArea(area);
    }

    @PostMapping
    public ResponseEntity<Professor> cadastrar(@Valid @RequestBody ProfessorRequest dados) {
        Professor professor = service.cadastrar(dados);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(professor.getId()).toUri();
        return ResponseEntity.created(location).body(professor);
    }

    @PutMapping("/{id}")
    public Professor atualizar(@PathVariable Long id, @Valid @RequestBody ProfessorRequest dados) {
        return service.atualizar(id, dados);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
