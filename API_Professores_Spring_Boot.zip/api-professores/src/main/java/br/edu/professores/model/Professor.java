package br.edu.professores.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import org.hibernate.annotations.Formula;

@Entity
@Table(name = "professor")
public class Professor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(nullable = false, length = 150)
    private String email;

    @Column(nullable = false, length = 100)
    private String area;

    @Column(nullable = false, length = 20)
    private String telefone;

    // Atributo calculado de leitura: não cria uma sexta coluna na tabela.
    @Formula("public.unaccent(nome)")
    @JsonIgnore
    private String nomeBusca;

    public Professor() { }

    public Professor(String nome, String email, String area, String telefone) {
        this.nome = nome;
        this.email = email;
        this.area = area;
        this.telefone = telefone;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
}
