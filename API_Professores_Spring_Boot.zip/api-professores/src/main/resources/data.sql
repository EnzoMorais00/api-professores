-- Executado somente quando o perfil demo estiver ativo.
-- Inserções idempotentes: reiniciar a aplicação não duplica esses registros.
INSERT INTO professor (nome, email, area, telefone)
SELECT 'João da Silva', 'joao.silva@example.com', 'Desenvolvimento', '86999990001'
WHERE NOT EXISTS (SELECT 1 FROM professor WHERE email = 'joao.silva@example.com');
INSERT INTO professor (nome, email, area, telefone)
SELECT 'João Pedro', 'joao.pedro@example.com', 'Desenvolvimento', '86999990002'
WHERE NOT EXISTS (SELECT 1 FROM professor WHERE email = 'joao.pedro@example.com');
INSERT INTO professor (nome, email, area, telefone)
SELECT 'MARIA JOANA', 'maria.joana@example.com', 'Engenharia de Software', '86999990003'
WHERE NOT EXISTS (SELECT 1 FROM professor WHERE email = 'maria.joana@example.com');
INSERT INTO professor (nome, email, area, telefone)
SELECT 'Ana Costa', 'ana.costa@example.com', 'Banco de Dados', '86999990004'
WHERE NOT EXISTS (SELECT 1 FROM professor WHERE email = 'ana.costa@example.com');
