-- Sem carga de demonstração no perfil padrão.
SELECT 1;
