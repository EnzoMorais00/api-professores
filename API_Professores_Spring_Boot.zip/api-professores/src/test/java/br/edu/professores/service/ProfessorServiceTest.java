package br.edu.professores.service;

import br.edu.professores.dto.ProfessorRequest;
import br.edu.professores.exception.ProfessorNaoEncontradoException;
import br.edu.professores.model.Professor;
import br.edu.professores.repository.ProfessorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Optional;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProfessorServiceTest {
    ProfessorRepository repository;
    ProfessorService service;

    @BeforeEach
    void configurar() {
        repository = mock(ProfessorRepository.class);
        service = new ProfessorService(repository);
    }

    @Test
    void normalizaAcentosAntesDaConsultaDerivada() {
        service.filtrarPorNome(" João ");
        verify(repository).findByNomeBuscaContainingIgnoreCaseOrderByIdAsc("Joao");
    }

    @Test
    void areaUsaConsultaDerivadaExata() {
        service.filtrarPorArea(" desenvolvimento ");
        verify(repository).findByAreaIgnoreCaseOrderByIdAsc("desenvolvimento");
    }

    @Test
    void atualizarPreservaEntidadeExistente() {
        Professor existente = new Professor("Antigo", "antigo@example.com", "Antiga", "111");
        when(repository.findById(7L)).thenReturn(Optional.of(existente));
        when(repository.save(existente)).thenReturn(existente);
        Professor resultado = service.atualizar(7L,
                new ProfessorRequest(" Novo ", "novo@example.com", "Nova", "222"));
        assertThat(resultado).isSameAs(existente);
        assertThat(resultado.getNome()).isEqualTo("Novo");
        assertThat(resultado.getEmail()).isEqualTo("novo@example.com");
        assertThat(resultado.getArea()).isEqualTo("Nova");
        assertThat(resultado.getTelefone()).isEqualTo("222");
    }

    @Test
    void naoCriaProfessorAoAtualizarIdInexistente() {
        when(repository.findById(7L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.atualizar(7L,
                new ProfessorRequest("Nome", "nome@example.com", "Area", "123")))
                .isInstanceOf(ProfessorNaoEncontradoException.class);
        verify(repository, never()).save(any());
    }

    @Test
    void excluirInexistenteRetornaErro() {
        when(repository.findById(7L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.excluir(7L))
                .isInstanceOf(ProfessorNaoEncontradoException.class);
        verify(repository, never()).delete(any());
    }
}
