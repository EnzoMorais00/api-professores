package br.edu.professores;

import br.edu.professores.dto.ProfessorRequest;
import br.edu.professores.model.Professor;
import br.edu.professores.repository.ProfessorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import javax.sql.DataSource;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class ProfessorApiIT {
    @Autowired TestRestTemplate http;
    @Autowired ProfessorRepository repository;
    @Autowired DataSource dataSource;

    @BeforeEach
    void preparar() throws Exception {
        // Impede que a rotina de limpeza seja executada no banco de uso normal.
        try (var connection = dataSource.getConnection()) {
            if (!connection.getCatalog().endsWith("_test")) {
                throw new IllegalStateException("Use um banco exclusivo com sufixo _test");
            }
        }
        repository.deleteAll();
        repository.saveAll(List.of(
                new Professor("João da Silva", "joao@example.com", "Desenvolvimento", "86999990001"),
                new Professor("João Pedro", "pedro@example.com", "DESENVOLVIMENTO", "86999990002"),
                new Professor("MARIA JOANA", "joana@example.com", "Banco de Dados", "86999990003")));
    }

    @Test
    void listarRetornaTodos() {
        var resposta = http.getForEntity("/professores", Professor[].class);
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resposta.getBody()).hasSize(3);
    }

    @Test
    void nomeParcialIgnoraCaixaEAcentos() {
        var resposta = http.getForEntity("/professores/nome/{nome}", Professor[].class, "joao");
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resposta.getBody()).extracting(Professor::getNome)
                .containsExactly("João da Silva", "João Pedro");
        var todos = http.getForEntity("/professores/nome/{nome}", Professor[].class, "JOÃ");
        assertThat(todos.getBody()).hasSize(3);
        var maria = http.getForEntity("/professores/nome/mArIa", Professor[].class);
        assertThat(maria.getBody()).extracting(Professor::getNome).containsExactly("MARIA JOANA");
    }

    @Test
    void areaExataIgnoraCaixa() {
        var resposta = http.getForEntity("/professores/area/desenvolvimento", Professor[].class);
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resposta.getBody()).hasSize(2);
        assertThat(http.getForObject("/professores/area/Desenv", Professor[].class)).isEmpty();
    }

    @Test
    void cadastrarPersisteERetornaLocation() {
        var resposta = http.postForEntity("/professores", dados(), Professor.class);
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        Professor criado = resposta.getBody();
        assertThat(criado).isNotNull();
        assertThat(criado.getId()).isPositive();
        assertThat(repository.findById(criado.getId())).isPresent();
        assertThat(resposta.getHeaders().getLocation()).isNotNull();
        var consulta = http.getForEntity(resposta.getHeaders().getLocation(), Professor.class);
        assertThat(consulta.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(consulta.getBody().getNome()).isEqualTo("Maria Silva");
    }

    @Test
    void editarAtualizaTodosOsCampos() {
        Long id = repository.findAll().get(0).getId();
        var novos = new ProfessorRequest("Maria Silva Santos", "mariasantos@example.com",
                "Engenharia de Software", "86988888888");
        var resposta = http.exchange("/professores/" + id, HttpMethod.PUT,
                new HttpEntity<>(novos), Professor.class);
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resposta.getBody().getId()).isEqualTo(id);
        Professor salvo = repository.findById(id).orElseThrow();
        assertThat(salvo.getNome()).isEqualTo(novos.nome());
        assertThat(salvo.getEmail()).isEqualTo(novos.email());
        assertThat(salvo.getArea()).isEqualTo(novos.area());
        assertThat(salvo.getTelefone()).isEqualTo(novos.telefone());
    }

    @Test
    void excluirRemoveRegistroERetorna204() {
        Long id = repository.findAll().get(0).getId();
        var resposta = http.exchange("/professores/" + id, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
        assertThat(resposta.getBody()).isNull();
        assertThat(repository.existsById(id)).isFalse();
        assertThat(http.getForEntity("/professores/" + id, String.class).getStatusCode())
                .isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void idInexistenteRetorna404() {
        String url = "/professores/9223372036854775807";
        assertThat(http.getForEntity(url, String.class).getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(http.exchange(url, HttpMethod.PUT, new HttpEntity<>(dados()), String.class)
                .getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(http.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class)
                .getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void dadosInvalidosRetornam400() {
        var invalidos = new ProfessorRequest("", "nao-e-email", "", "");
        var resposta = http.postForEntity("/professores", invalidos, String.class);
        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(repository.count()).isEqualTo(3);
        assertThat(http.getForEntity("/professores/abc", String.class).getStatusCode())
                .isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void filtrosSemCorrespondenciaRetornamListaVazia() {
        assertThat(http.getForObject("/professores/nome/zzzinexistente", Professor[].class)).isEmpty();
        assertThat(http.getForObject("/professores/nome/{nome}", Professor[].class, "%")).isEmpty();
        assertThat(http.getForObject("/professores/area/Inexistente", Professor[].class)).isEmpty();
    }

    private ProfessorRequest dados() {
        return new ProfessorRequest("Maria Silva", "maria@example.com", "Desenvolvimento", "86999999999");
    }
}
