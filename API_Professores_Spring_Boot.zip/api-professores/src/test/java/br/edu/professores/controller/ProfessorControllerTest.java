package br.edu.professores.controller;

import br.edu.professores.exception.ProfessorNaoEncontradoException;
import br.edu.professores.model.Professor;
import br.edu.professores.service.ProfessorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProfessorController.class)
class ProfessorControllerTest {
    @Autowired MockMvc mvc;
    @MockitoBean ProfessorService service;
    private static final String JSON = """
        {"nome":"Maria Silva","email":"maria@example.com","area":"Desenvolvimento","telefone":"86999999999"}
        """;

    private Professor professor() throws Exception {
        Professor professor = new Professor("Maria Silva", "maria@example.com", "Desenvolvimento", "86999999999");
        var id = Professor.class.getDeclaredField("id");
        id.setAccessible(true);
        id.set(professor, 10L);
        return professor;
    }

    @Test void listar() throws Exception {
        when(service.listar()).thenReturn(List.of(professor()));
        mvc.perform(get("/professores")).andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nome").value("Maria Silva"))
                .andExpect(jsonPath("$[0].nomeBusca").doesNotExist());
    }
    @Test void buscarPorId() throws Exception {
        when(service.buscarPorId(10L)).thenReturn(professor());
        mvc.perform(get("/professores/10")).andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10));
    }
    @Test void filtrarNome() throws Exception {
        when(service.filtrarPorNome("maria")).thenReturn(List.of(professor()));
        mvc.perform(get("/professores/nome/maria")).andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nome").value("Maria Silva"));
    }
    @Test void filtrarArea() throws Exception {
        when(service.filtrarPorArea("desenvolvimento")).thenReturn(List.of(professor()));
        mvc.perform(get("/professores/area/desenvolvimento")).andExpect(status().isOk())
                .andExpect(jsonPath("$[0].area").value("Desenvolvimento"));
    }
    @Test void cadastrar() throws Exception {
        when(service.cadastrar(any())).thenReturn(professor());
        mvc.perform(post("/professores").contentType(MediaType.APPLICATION_JSON).content(JSON))
                .andExpect(status().isCreated()).andExpect(header().string("Location", "http://localhost/professores/10"))
                .andExpect(jsonPath("$.id").value(10));
    }
    @Test void editar() throws Exception {
        when(service.atualizar(eq(10L), any())).thenReturn(professor());
        mvc.perform(put("/professores/10").contentType(MediaType.APPLICATION_JSON).content(JSON))
                .andExpect(status().isOk()).andExpect(jsonPath("$.nome").value("Maria Silva"));
    }
    @Test void excluir() throws Exception {
        mvc.perform(delete("/professores/10")).andExpect(status().isNoContent()).andExpect(content().string(""));
        verify(service).excluir(10L);
    }
    @Test void inexistente() throws Exception {
        when(service.buscarPorId(99L)).thenThrow(new ProfessorNaoEncontradoException(99L));
        mvc.perform(get("/professores/99")).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail").value("Professor com id 99 não encontrado"));
    }
    @Test void validarCampos() throws Exception {
        mvc.perform(post("/professores").contentType(MediaType.APPLICATION_JSON)
                .content("{\"nome\":\"\",\"email\":\"invalido\",\"area\":\"\",\"telefone\":\"\"}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.campos.nome").exists());
        verifyNoInteractions(service);
    }
    @Test void jsonMalformado() throws Exception {
        mvc.perform(post("/professores").contentType(MediaType.APPLICATION_JSON).content("{"))
                .andExpect(status().isBadRequest());
    }
    @Test void idInvalido() throws Exception {
        mvc.perform(delete("/professores/abc")).andExpect(status().isBadRequest());
    }
}
