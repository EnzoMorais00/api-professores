-- Os testes criam seus próprios dados em um banco separado.
SELECT 1;
