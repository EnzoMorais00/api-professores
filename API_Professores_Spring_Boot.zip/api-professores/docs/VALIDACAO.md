# Validação do projeto

Data: 28/09/2026.

## Resultado

**25 testes aprovados, zero falhas, zero erros e zero testes ignorados.**

- 5 testes unitários de Service com Mockito.
- 11 testes web de Controller com MockMvc.
- 9 testes de integração HTTP com Spring Boot, JPA, driver JDBC PostgreSQL e banco PostgreSQL executado em PGlite.
- Seis operações HTTP adicionais executadas pelo cliente Python, com capturas reais dos relatórios no Chromium.
- Banco reaberto após encerrar a API e o servidor para verificar a permanência dos quatro registros iniciais.

```text
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 10.98 s -- in br.edu.professores.service.ProfessorServiceTest
[INFO] Tests run: 11, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.752 s -- in br.edu.professores.controller.ProfessorControllerTest
[INFO] Tests run: 16, Failures: 0, Errors: 0, Skipped: 0
[INFO] Tests run: 9, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 14.96 s -- in br.edu.professores.ProfessorApiIT
[INFO] Tests run: 9, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

Consulte a [saída Maven completa](evidencias/maven-verificacao.txt) e as [evidências HTTP e SQL](evidencias/).

## Ambiente efetivamente executado

- Java 17 e Maven 3.9.11.
- Spring Boot 3.5.16 e Hibernate 6.6.53.Final.
- Driver PostgreSQL JDBC 42.7.11.
- PostgreSQL **18.3 (PGlite 0.5.8)**, compilado para WebAssembly.
- Servidor TCP `@electric-sql/pglite-socket` 0.2.11.
- Banco da aplicação: `professores_db`, porta 5432.
- Banco isolado de testes: `professores_test`, porta 5433.
- Persistência em disco; extensão `unaccent` ativada.
- Pool Hikari limitado a uma conexão nesta verificação.

A API conectou pelo JDBC e o Hibernate validou o esquema. Os testes de integração acessaram a aplicação por HTTP, confirmando persistência, atualização, exclusão, filtros, acentos e erros. Esses nove testes não substituíram o Repository ou o banco por mocks, nem utilizaram H2.

A verificação das capturas identificou e corrigiu uma referência mutável no script de evidências: o corpo de cada requisição agora é preservado no momento do envio. Depois da correção, as seis operações foram executadas novamente e todos os prints foram recapturados.

## Limites e pendências

O PostgreSQL convencional não pôde ser iniciado sob as restrições do ambiente. Foi usado o motor PostgreSQL em WebAssembly, com execução real de SQL e armazenamento persistente. O modo PGlite difere de uma instalação nativa, especialmente em conexões concorrentes; os resultados não devem ser apresentados como teste de PostgreSQL 16 nativo ou Docker.

Ainda não foram executados:

- Construção e inicialização pelo Docker Compose com PostgreSQL 16 nativo.
- Workflow GitHub Actions e publicação pública do repositório.

Também faltam o nome completo do aluno, a disciplina e a entrega do link na Plataforma A.

## Reprodução

O README contém instruções para PostgreSQL nativo/Docker e para a alternativa `dev-postgres` usada aqui. O comando `mvn verify` executa os 25 testes; o script `scripts/testar_e_gerar_evidencias.py` executa e captura as seis operações HTTP, com a API previamente iniciada.
