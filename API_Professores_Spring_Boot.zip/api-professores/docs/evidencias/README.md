# Evidências reais de execução

Capturadas em 28/09/2026 a partir de chamadas HTTP reais à API Spring Boot conectada pelo JDBC ao PostgreSQL 18.3 em WebAssembly (PGlite 0.5.8). Não houve mock do banco nos testes de integração nem nas chamadas capturadas.

Os arquivos 01 a 06 contêm o registro JSON, o relatório HTML e a captura PNG de cada operação. O arquivo `07-banco.json` documenta consultas SQL após reabrir o banco persistido. `maven-verificacao.txt` registra os 25 testes aprovados.

A execução nativa com PostgreSQL 16/Docker e a publicação GitHub ainda não foram feitas. Consulte o README principal e `../VALIDACAO.md`.
