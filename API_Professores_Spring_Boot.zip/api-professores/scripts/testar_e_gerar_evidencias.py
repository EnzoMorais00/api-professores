#!/usr/bin/env python3
"""Testa a API em execução e captura seis prints de um relatório HTTP real.

Use uma base de demonstração. O script cria registros próprios e os remove.
Não simula respostas: qualquer status ou conteúdo incorreto interrompe a execução.
"""
import argparse
from datetime import datetime, timezone
import html
import json
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen
from uuid import uuid4


def chamar(base, metodo, caminho, esperado, dados=None):
    url = base.rstrip('/') + quote(caminho, safe='/')
    corpo = None if dados is None else json.dumps(dados, ensure_ascii=False).encode('utf-8')
    inicio = datetime.now(timezone.utc)
    request = Request(url, data=corpo, method=metodo,
                      headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
    try:
        resposta = urlopen(request, timeout=30)
    except HTTPError as erro:
        resposta = erro
    with resposta:
        bruto = resposta.read().decode('utf-8')
        status = resposta.status
        headers = dict(resposta.headers)
    resultado = json.loads(bruto) if bruto else None
    assert status == esperado, f'{metodo} {url}: esperado {esperado}, recebido {status}: {bruto}'
    return {'data_utc': inicio.isoformat(), 'metodo': metodo, 'url': url,
            'enviado': None if corpo is None else json.loads(corpo.decode('utf-8')), 'status': status, 'headers': headers, 'resposta': resultado,
            'duracao_ms': round((datetime.now(timezone.utc) - inicio).total_seconds() * 1000)}


def formatar(valor):
    return '(sem corpo)' if valor is None else json.dumps(valor, ensure_ascii=False, indent=2)


def pagina(titulo, registro):
    esc = lambda s: html.escape(str(s))
    confirmacao = registro.get('confirmacao')
    extra = ''
    if confirmacao:
        extra = ('<section><h2>Confirmação após exclusão</h2><p>GET ' + esc(confirmacao['url']) +
                 ' · HTTP ' + str(confirmacao['status']) + '</p><pre>' +
                 esc(formatar(confirmacao['resposta'])) + '</pre></section>')
    return '''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Evidência HTTP</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#edf2f7;color:#172b42;font:16px Arial,sans-serif}
main{margin:32px auto;width:1136px}header{background:#163654;color:white;padding:28px;border-radius:12px}
h1{margin:8px 0 18px;font-size:27px}.kicker{font-size:12px;letter-spacing:2px}
.url{font:16px monospace;overflow-wrap:anywhere}.status{display:inline-block;background:#ddf5e6;color:#115d35;padding:8px 12px;border-radius:6px;margin:18px 0 0}
section{background:white;border:1px solid #d7e0e9;padding:22px;margin-top:18px;border-radius:10px}
h2{font-size:15px;margin:0 0 14px}pre{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;font:15px/1.5 monospace}
footer{margin:18px 0;font-size:12px;color:#48617a}
</style><main><header><div class="kicker">API DE PROFESSORES · EVIDÊNCIA DE EXECUÇÃO HTTP</div><h1>''' + esc(titulo) + '''</h1><div class="url">''' + esc(registro['metodo'] + ' ' + registro['url']) + '''</div><div class="status">HTTP ''' + str(registro['status']) + ' · ' + str(registro['duracao_ms']) + ''' ms</div></header><section><h2>Dados enviados</h2><pre>''' + esc(formatar(registro['enviado'])) + '''</pre></section><section><h2>Resposta recebida da API</h2><pre>''' + esc(formatar(registro['resposta'])) + '</pre></section>' + extra + '<footer>Captura do relatório gerado pelo cliente Python a partir de chamadas reais. Execução (UTC): ' + esc(registro['data_utc']) + '</footer></main></html>'


def executar(base, saida):
    from playwright.sync_api import sync_playwright
    # Verifica o navegador antes de criar dados na API.
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        browser.close()
    ids = set()
    registros = []
    sufixo = uuid4().hex[:10]
    try:
        # Dados controlados para testar caixa e acentos independentemente da carga demo.
        for nome in ['João da Silva', 'João Pedro', 'MARIA JOANA']:
            r = chamar(base, 'POST', '/professores', 201,
                       {'nome': nome, 'email': f'{uuid4().hex}@example.com',
                        'area': 'Desenvolvimento', 'telefone': '86999990000'})
            ids.add(r['resposta']['id'])
        r = chamar(base, 'GET', '/professores', 200)
        assert ids <= {p['id'] for p in r['resposta']}
        registros.append(('01-listar', 'Caso 1 — Listar professores', r))
        r = chamar(base, 'GET', '/professores/nome/joao', 200)
        achados = {p['nome'] for p in r['resposta']}
        assert {'João da Silva', 'João Pedro'} <= achados
        assert 'MARIA JOANA' not in achados
        registros.append(('02-nome', 'Caso 2 — Filtrar por nome', r))
        parcial = chamar(base, 'GET', '/professores/nome/JOA', 200)
        assert ids <= {p['id'] for p in parcial['resposta']}
        r = chamar(base, 'GET', '/professores/area/desenvolvimento', 200)
        assert ids <= {p['id'] for p in r['resposta']}
        assert all(p['area'].lower() == 'desenvolvimento' for p in r['resposta'])
        registros.append(('03-area', 'Caso 3 — Filtrar por área', r))
        dados = {'nome': 'Maria Silva', 'email': f'maria.{sufixo}@example.com',
                 'area': 'Desenvolvimento', 'telefone': '86999999999'}
        r = chamar(base, 'POST', '/professores', 201, dados)
        professor_id = r['resposta']['id']
        ids.add(professor_id)
        assert r['resposta'] == dict(dados, id=professor_id)
        consulta = chamar(base, 'GET', f'/professores/{professor_id}', 200)
        assert consulta['resposta'] == r['resposta']
        registros.append(('04-cadastrar', 'Caso 4 — Cadastrar professor', r))
        dados.update(nome='Maria Silva Santos', email=f'mariasantos.{sufixo}@example.com',
                     area='Engenharia de Software', telefone='86988888888')
        r = chamar(base, 'PUT', f'/professores/{professor_id}', 200, dados)
        assert r['resposta'] == dict(dados, id=professor_id)
        consulta = chamar(base, 'GET', f'/professores/{professor_id}', 200)
        assert consulta['resposta'] == r['resposta']
        registros.append(('05-editar', 'Caso 5 — Editar professor', r))
        r = chamar(base, 'DELETE', f'/professores/{professor_id}', 204)
        assert r['resposta'] is None
        ids.remove(professor_id)
        r['confirmacao'] = chamar(base, 'GET', f'/professores/{professor_id}', 404)
        registros.append(('06-excluir', 'Caso 6 — Excluir e confirmar remoção', r))
        saida.mkdir(parents=True, exist_ok=True)
        with sync_playwright() as pw:
            browser = pw.chromium.launch()
            page = browser.new_page(viewport={'width': 1200, 'height': 900}, device_scale_factor=1)
            for arquivo, titulo, registro in registros:
                (saida / (arquivo + '.json')).write_text(json.dumps(registro, ensure_ascii=False, indent=2), encoding='utf-8')
                conteudo = pagina(titulo, registro)
                (saida / (arquivo + '.html')).write_text(conteudo, encoding='utf-8')
                page.set_content(conteudo)
                page.screenshot(path=str(saida / (arquivo + '.png')), full_page=True)
                print(f'OK {registro["metodo"]} {registro["url"]} -> {registro["status"]}')
            browser.close()
        print(f'Seis operações confirmadas. Evidências em: {saida.resolve()}')
    finally:
        for professor_id in ids:
            try:
                chamar(base, 'DELETE', f'/professores/{professor_id}', 204)
            except Exception as erro:
                print(f'Aviso: não foi possível limpar o registro {professor_id}: {erro}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url', default='http://localhost:8080')
    parser.add_argument('--saida', type=Path, default=Path(__file__).resolve().parents[1] / 'docs/evidencias')
    args = parser.parse_args()
    executar(args.base_url, args.saida)
