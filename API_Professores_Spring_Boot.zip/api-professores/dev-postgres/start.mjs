import { PGlite } from '@electric-sql/pglite';
import { unaccent } from '@electric-sql/pglite/contrib/unaccent';
import { PGLiteSocketServer } from '@electric-sql/pglite-socket';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdir } from 'node:fs/promises';
const dataRoot=path.join(path.dirname(fileURLToPath(import.meta.url)),'data');
await mkdir(dataRoot,{recursive:true});
const instances=[];
for (const [name,port] of [['professores_db',5432],['professores_test',5433]]) {
 const dataDir=path.join(dataRoot,name);
 const bootstrap=await PGlite.create({dataDir,extensions:{unaccent}});
 const exists=await bootstrap.query('SELECT 1 FROM pg_database WHERE datname=$1',[name]);
 if(!exists.rows.length) await bootstrap.exec('CREATE DATABASE '+name);
 await bootstrap.close();
 const db=await PGlite.create({dataDir,database:name,extensions:{unaccent}});
 const info=await db.query('SELECT version(), current_database() AS banco');
 const server=new PGLiteSocketServer({db,host:'127.0.0.1',port,maxConnections:1});
 await server.start();
 instances.push({db,server});
 console.log(JSON.stringify({port,...info.rows[0]}));
}
async function close(){for(const {db,server} of instances){await server.stop();await db.close();}process.exit(0);}
process.on('SIGINT',close);process.on('SIGTERM',close);
