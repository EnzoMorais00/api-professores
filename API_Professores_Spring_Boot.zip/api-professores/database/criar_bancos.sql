-- Execute como administrador no pgAdmin/psql, fora de uma transação.
-- Crie apenas os bancos que ainda não existem.
CREATE DATABASE professores_db;
CREATE DATABASE professores_test;
-- A aplicação executa src/main/resources/schema.sql automaticamente ao iniciar.
